﻿//The sum of Primes below 10 is 17

//What is the sum of primes below 2000000?

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Euler_Project_10
{
    class Program
    {
        static void Main(string[] args)
        {
            int value = 11;
            bool primeness;
            primeness = CheckPrime(value);
            Console.WriteLine(primeness);

            Console.ReadLine();
        }


        static bool CheckPrime(int dividend)
        {
            int divisor = 2;

            while ( divisor < (int)Math.Ceiling(Math.Sqrt(dividend)) )
            {
                int remainder = dividend % divisor;
                if (remainder == 0)
                {
                    return false;

                }
                else
                {
                    divisor++;
                }
            }
            return true;
        }
    }
}
