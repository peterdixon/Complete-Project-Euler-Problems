﻿/*Highly Divisible triangular number
 *the nth triangular number is 1+2+3+...+n
 *the 7th is 1+2+3+4+5+6+7 = 28
 * the first ten are 1,3,6,10,15,21,28,36,45,55
 * their factors are
 * 1: 1
 * 3: 1,3
 * 6: 1,2,3,6,
 * 10: 1,3,5,10
 * 21: 1,3,7,21
 * 28: 1,2,4,7,14,28
 * We see 28 is the first triangular number to have over 5 divisors
 * What is the value of the first triangular number to have over 500 divisors?
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EulerProblem11
{
    class Program
    {
        static void Main(string[] args)
        {
            //Idea: every natural number has the form A = p_1^a_1 p_2^a_2 ... p_n^a_n where the p_i are primes less than or equal to
            //B = the ceiling of A's square root
            //Every prime p_i up to B that does not divide A has a_i = 0.
            //Lets suppose q is a divisor of A. Then q = p_1 b^1 ... p_n b^n where 0 \le b_i \le a_i.

            int number = 2;
            //int numberOfFactors = 1;

            int[] listOfPrimes;
            listOfPrimes = new int[20];

            for(int i = 0; i<listOfPrimes.Length; i++)
            {
                listOfPrimes[i] = 0;
            }

            listOfPrimes[0] = 2;

            int pi_count = 0;
            while(number < 100)
            {

                if (TestPrimeness(number, listOfPrimes) == true)
                {
                    listOfPrimes[pi_count] = number;
                    pi_count++;
                    Console.WriteLine(listOfPrimes);
                }


            }
            //Method: generate a list of primes less than B. and store them in an array.
            //For each triangle number, divide them by each p_i until the remainder != 0.
            //Ex for 28, divide by 2, 2 and then we get 28% 2 = 0 -> (28/2) % 2 = 0 -> (28/2/2) % 2 = 1. At this point, 28 is divisible by 4 and not 8.
            //We do not increment and we break the remainder loop. 


            //Counting the divisors:
            //for each a_i, there are a_i + 1 ways to assign them a b_i. hence number of factors
            //is equal to
            // Product_(i=1^i=n)(a_i+1).
            


        }
        //This function takes the list of primes that we have obtained and sees if the input dividend is prime.
        static bool TestPrimeness(int dividend, int[] primesList)
        {

            //Case: if dividend = divisor = 2 then since 2 = upperbound, the while loop doesnt run.
            //Case: if dividend =3 and divisor = 2, then same.
            //If dividend = 4, divisor = 2 on first run and hence remainder = 0. We want to return false.
            //If dividend = 5 we want to return true.

            bool result = false;
            int upperbound = (int)Math.Ceiling(Math.Sqrt(dividend))+1;
            int i = 0;
            int remainder;
            while (primesList[i] < upperbound)
            {
                remainder = dividend % primesList[i];

                //If remainder is 0, end the loop so we can return false.
                if(remainder == 0)
                {
                    break;
                }
                //The remainder is not 0, we check the next i.
                else
                {
                    ++i;
                    //If we reach the upper bound, we set result = true.
                    if (primesList[i] == upperbound)
                    {
                        result = true;
                    }
                }
            }

            return result;

        }
    }
}
