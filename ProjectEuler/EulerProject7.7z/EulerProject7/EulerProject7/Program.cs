﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EulerProject7
{
    class Program
    {
        static void Main(string[] args)
        {
            bool primeness = true;
            int value = 1;
            int primeCounter = 1;

            while (primeCounter < 10001)
            {
                //Increase the value we're examining.
                value++;
                primeness = checkPrimeness(value);

                //If value is a prime number, add 1 to the prime counter.
                if (primeness == true)
                {
                    primeCounter++;

                    Console.WriteLine("The {1}'th prime is {0}", value, primeCounter);



                }
            }

            //Test if the current value is prime.
            Console.ReadLine();

        }

        static bool checkPrimeness(int dividend)
        {


            int remainder;
            int divisor = 2;
            int UpperBound = (int)Math.Ceiling(Math.Sqrt(dividend))+1;

            while (divisor < UpperBound)
            {
                remainder = dividend % divisor;

                if (remainder == 0)
                {
                    return false;
                }
                divisor++;
            }

            return true;
        }

        }
    }


          